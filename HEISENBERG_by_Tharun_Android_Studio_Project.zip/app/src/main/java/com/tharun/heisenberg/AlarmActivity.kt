package com.tharun.heisenberg

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.media.Ringtone
import android.media.RingtoneManager
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class AlarmActivity : Activity() {
    private var ringtone: Ringtone? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
        ringtone?.play()
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(32,32,32,32); setBackgroundColor(Color.rgb(16,29,56)) }
        layout.addView(TextView(this).apply { text="4:00 AM"; textSize=48f; setTextColor(Color.WHITE); gravity=Gravity.CENTER })
        layout.addView(TextView(this).apply { text="HEISENBERG • BY THARUN\nYour future is built one focused morning at a time."; textSize=20f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(0,24,0,40) })
        layout.addView(Button(this).apply { text="STOP ALARM"; setOnClickListener { ringtone?.stop(); finish() } })
        setContentView(layout)
    }
    override fun onDestroy() { ringtone?.stop(); super.onDestroy() }
}
