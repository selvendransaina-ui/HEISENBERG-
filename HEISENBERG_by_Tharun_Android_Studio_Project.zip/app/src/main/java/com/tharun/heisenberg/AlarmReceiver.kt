package com.tharun.heisenberg

import android.app.*
import android.content.*
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val channel = "heisenberg_alarm"
        val manager = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channel, "Study alarm", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Daily 4:00 AM study wake-up alarm"
                setSound(null, null)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            })
        }
        val full = PendingIntent.getActivity(context, 2, Intent(context, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("HEISENBERG • 4:00 AM")
            .setContentText("Good morning. Your study session is ready.")
            .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX)
            .setFullScreenIntent(full, true).setContentIntent(full).setAutoCancel(true).build()
        manager.notify(400, n)
        // Schedule the next daily occurrence.
        AlarmScheduler.schedule(context)
    }
}
