package com.tharun.heisenberg

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit

private data class Q(val subject:String,val chapter:String,val question:String,val options:List<String>,val answer:Int,val explanation:String)
private val navy=Color(0xFF101D38)
private val bank=listOf(
 Q("Physics","Electrostatics","What is the SI unit of electric charge?",listOf("Ampere","Coulomb","Volt","Ohm"),1,"Electric charge is measured in coulombs (C)."),
 Q("Physics","Current Electricity","Which law relates current, voltage and resistance?",listOf("Newton's law","Ohm's law","Faraday's law","Hooke's law"),1,"Ohm's law: V = IR."),
 Q("Chemistry","Solutions","The SI unit commonly used for molarity is:",listOf("mol kg⁻¹","mol L⁻¹","g L⁻¹","kg mol⁻¹"),1,"Molarity is moles of solute per litre of solution."),
 Q("Chemistry","Electrochemistry","Oxidation occurs at the:",listOf("Cathode","Anode","Salt bridge","Voltmeter"),1,"Oxidation takes place at the anode."),
 Q("Mathematics","Applications of Derivatives","The derivative of x² with respect to x is:",listOf("x","2x","x³","2"),1,"Using the power rule, d(x²)/dx = 2x."),
 Q("Mathematics","Matrices","A square matrix has:",listOf("One row only","Equal rows and columns","One column only","No diagonal"),1,"A square matrix has the same number of rows and columns."),
 Q("Biology","Molecular Genetics","Which molecule carries hereditary information in most organisms?",listOf("Protein","DNA","Glucose","Lipid"),1,"DNA stores hereditary information in most organisms."),
 Q("Biology","Human Reproduction","Fertilisation in humans normally occurs in the:",listOf("Uterus","Oviduct","Cervix","Vagina"),1,"Fertilisation usually occurs in the ampullary region of the oviduct."),
 Q("Tamil","தமிழ் இலக்கணம்","பெயர்ச்சொல் எதைக் குறிக்கிறது?",listOf("செயலை","பொருள் அல்லது நபரை","பண்பை மட்டும்","காலத்தை"),1,"பெயர்ச்சொல் ஒரு பொருள், இடம், நபர் போன்றவற்றைக் குறிக்கும்."),
 Q("English","Grammar","Choose the correct passive form: 'She writes a letter.'",listOf("A letter is written by her.","A letter was written by her.","A letter has write.","A letter wrote her."),0,"Simple present passive uses is/am/are + past participle.")
)
private val timetable=listOf("4:00–4:10 AM  • Wake up, water and get ready","4:10–5:00 AM  • Mathematics practice","5:00–5:50 AM  • Physics concepts and numericals","5:50–6:10 AM  • Break","6:10–6:50 AM  • Chemistry revision","School hours  • Attend classes; note doubts","4:30–5:00 PM  • Rest and snack","5:00–5:50 PM  • Biology diagrams and concepts","5:50–6:30 PM  • Tamil / English (alternate focus)","6:30–7:15 PM  • Homework and same-day revision","7:15–7:30 PM  • Daily 5-question test","7:30–8:00 PM  • Dinner and prepare for sleep","8:00 PM  • Sleep (protect 8 hours)")
class MainActivity : ComponentActivity() {
    private val notifPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
        if(Build.VERSION.SDK_INT>=33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { AppScreen(
            onAlarm={
                if(Build.VERSION.SDK_INT>=31 && !(getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms())
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                else AlarmScheduler.schedule(this)
            },
            onCancel={AlarmScheduler.cancel(this)}
        ) }
    }
}
@Composable private fun AppScreen(onAlarm:()->Unit,onCancel:()->Unit) {
    var page by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf(0) }
    var answers by remember { mutableStateOf(mapOf<Int,Int>()) }
    var submitted by remember { mutableStateOf(false) }
    val today=LocalDate.now()
    val start=LocalDate.of(2026,11,23); val end=LocalDate.of(2027,2,8)
    val day=ChronoUnit.DAYS.between(start,today).coerceIn(0,ChronoUnit.DAYS.between(start,end))
    val dailyQ=bank.filter { it.subject in listOf("Physics","Chemistry","Mathematics","Biology","Tamil","English") }.let { all -> (0..4).map { all[((day.toInt()*5+it)%all.size)] } }
    MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF79C8FF),background=navy,surface=Color(0xFF1B2B49))) {
        Scaffold(containerColor=navy, topBar={ Column(Modifier.fillMaxWidth().background(navy).padding(18.dp)) {
            Text("HEISENBERG",color=Color.White,fontSize=27.sp); Text("BY THARUN  •  CLASS XII TN STATE BOARD",color=Color(0xFF9BCBFF),fontSize=11.sp)
        } }) { pad ->
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf("Home","Questions","Daily Test","Timetable","Motivation").forEach { label -> Button(onClick={page=label},contentPadding=PaddingValues(horizontal=10.dp,vertical=6.dp)) { Text(label,fontSize=11.sp) } } } }
                item { Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF203B65)),shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) {
                    Text("THINK. LEARN. ACHIEVE.",color=Color(0xFFB9E3FF)); Text("Your board exam journey",color=Color.White,fontSize=22.sp)
                    Text("23 Nov 2026 – 08 Feb 2027",color=Color.White); Text("PCMB + Tamil + English  •  English Medium",color=Color(0xFFD6E9FF))
                    Text("Plan day ${day+1} of 78",color=Color(0xFFFFD77A))
                } } }
                when(page) {
                    "Home" -> {
                        item { Text("Today's focus",color=Color.White,fontSize=20.sp) }
                        items(listOf("Mathematics • problem solving","Physics • concepts + numericals","Chemistry • equations + reactions","Biology • diagrams + terminology","Tamil and English • alternate daily")) { Text("• $it",color=Color.White) }
                        item { Button(onClick=onAlarm,modifier=Modifier.fillMaxWidth()) { Text("Set daily 4:00 AM alarm") } }
                        item { OutlinedButton(onClick=onCancel,modifier=Modifier.fillMaxWidth()) { Text("Cancel alarm") } }
                        item { Text("Alarm note: Android may require exact-alarm and notification permission. No snooze is provided in the alarm screen; device settings, force-stop and manufacturer battery controls can still affect delivery.",color=Color(0xFFFFD77A),fontSize=12.sp) }
                    }
                    "Questions" -> {
                        item { Text("Chapter-wise starter question bank",color=Color.White,fontSize=19.sp); Text("Sample questions are included. Verify chapter coverage against your current Samacheer Kalvi textbook.",color=Color(0xFFFFD77A),fontSize=12.sp) }
                        items(bank) { q -> Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF1B2B49))) { Column(Modifier.padding(12.dp)) { Text("${q.subject} • ${q.chapter}",color=Color(0xFF9BCBFF)); Text(q.question,color=Color.White); Text("Answer: ${q.options[q.answer]}",color=Color(0xFF9FE3B1)); Text(q.explanation,color=Color.LightGray,fontSize=12.sp) } } }
                    }
                    "Daily Test" -> {
                        item { Text("Daily 5-question test",color=Color.White,fontSize=20.sp); Text("Answer all five, then submit.",color=Color.LightGray) }
                        items(dailyQ.size) { i -> val q=dailyQ[i]
                            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF1B2B49))) { Column(Modifier.padding(12.dp)) {
                                Text("Q${i+1}. ${q.subject} • ${q.chapter}",color=Color(0xFF9BCBFF)); Text(q.question,color=Color.White)
                                q.options.forEachIndexed { idx,opt -> Row { RadioButton(selected=answers[i]==idx,onClick={if(!submitted) answers=answers+(i to idx)},enabled=!submitted); Text(opt,color=Color.White,modifier=Modifier.padding(top=12.dp)) } }
                                if(submitted) Text(if(answers[i]==q.answer) "Correct • ${q.explanation}" else "Correct answer: ${q.options[q.answer]}. ${q.explanation}",color=Color(0xFFB9E3FF),fontSize=12.sp)
                            } }
                        }
                        item { Button(onClick={submitted=true},enabled=answers.size==5 && !submitted,modifier=Modifier.fillMaxWidth()) { Text("Submit test") } }
                        if(submitted) item { Text("Your score: ${dailyQ.indices.count { answers[it]==dailyQ[it].answer }} / 5",color=Color(0xFF9FE3B1),fontSize=22.sp); Button(onClick={answers=mapOf();submitted=false}) { Text("Retake") } }
                    }
                    "Timetable" -> { item { Text("Daily study timetable",color=Color.White,fontSize=20.sp); Text("School hours are reserved; adjust to your actual school/commute schedule.",color=Color.LightGray,fontSize=12.sp) }; items(timetable) { Text(it,color=Color.White,modifier=Modifier.padding(vertical=5.dp)) } }
                    else -> { item { Text("Daily motivation",color=Color.White,fontSize=20.sp); Text(listOf("Small progress every day becomes big achievement.","Consistency beats last-minute pressure.","Understand today. Revise tomorrow. Improve every day.","Every question you practise makes you more prepared.","Your effort today is an investment in your future.")[day.toInt()%5],color=Color.White,fontSize=22.sp); Text("You do not need to be perfect. Keep learning steadily and protect your sleep.",color=Color(0xFFB9E3FF)) } }
                }
                item { Spacer(Modifier.height(24.dp)); Text("HEISENBERG by Tharun • Study companion",color=Color.LightGray,fontSize=11.sp) }
            }
        }
    }
}
