# HEISENBERG by Tharun — Android Studio project

A starter Android app for Class 12 Tamil Nadu State Board (Samacheer Kalvi), English medium, PCMB + Tamil + English.

## Included
- Home dashboard and exam preparation date range (23 Nov 2026 to 08 Feb 2027)
- Chapter-labelled starter question bank across Physics, Chemistry, Mathematics, Biology, Tamil and English
- Daily 5-question quiz with scoring and explanations
- Daily motivational message
- Daily study timetable
- Daily 4:00 AM AlarmManager alarm, recurring after it fires, with a dedicated STOP-only alarm screen (no snooze button)

## Build
1. Install Android Studio (Ladybug or newer) and Android SDK 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync, then Run on an Android device/emulator (Android 8.0+).
4. On Android 13+, allow notifications. On Android 12+, allow exact alarms in the system prompt/settings if asked.
5. Tap **Set daily 4:00 AM alarm** in the app.

## Important limitations
- This is Android Studio source code, not a signed/compiled APK. Build an APK from Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- The included question bank is a small starter/sample bank, not a verified complete collection of all textbook chapter-wise board-important questions or previous-year questions. Add/verify questions against the current official Samacheer Kalvi books and board materials before relying on them.
- The alarm has no snooze control in the app, but Android/OEM battery settings, force-stop, permissions, reboot, or device policies can affect alarm delivery. Reboot rescheduling and guaranteed full-screen launch vary by Android version/manufacturer. Exact-alarm access may need to be enabled manually.
- The timetable is a suggested template. Adjust school and commute hours to the student's actual schedule. It schedules sleep at 8 PM to support adequate rest before a 4 AM wake-up.
- Daily quiz selection rotates through the starter question bank based on the calendar date; it is not a cloud-updated question feed.

## Build APK using only an Android phone (GitHub Actions)
This project can be built in the cloud without a laptop:
1. In Chrome, sign in to GitHub and create a new repository (a private repository is fine).
2. Upload the downloaded project ZIP to the repository root and name it exactly `heisenberg-project.zip`.
3. Create a new file with this exact path: `.github/workflows/build.yml`.
4. Paste the contents of the separate `HEISENBERG_build_workflow.yml` file into it and commit.
5. Open the repository's **Actions** tab, choose **Build HEISENBERG APK**, tap **Run workflow**, then wait for the green check.
6. Open the completed workflow run, scroll to **Artifacts**, download `HEISENBERG-debug-apk`, extract the artifact ZIP, and install `app-debug.apk`.
7. If Android asks, allow Chrome/Files to install unknown apps for this one installation, then turn that permission off again afterward.

The workflow builds a debug APK for personal testing. It is not a Play Store release-signed APK.
